export const timeDelayShowPromptAlert = {
  5010: 60 * 60 * 1000, // Điện thoại di động
  13010: 60 * 60 * 1000, // Việc làm
  13020: 60 * 60 * 1000, // Việc làm
  5030: 2 * 60 * 60 * 1000, // Máy tính, Laptop
  5020: 2 * 60 * 60 * 1000, // Tivi, Loa, Amply, Máy nghe nhạc
  default: 2.5 * 60 * 60 * 1000, // Default
};
